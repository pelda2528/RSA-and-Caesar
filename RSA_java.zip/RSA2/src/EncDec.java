import java.math.BigInteger;
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class EncDec {
BigInteger pmath,qmath,nmath,fimath,rmath,dmath,plainmath,c;
static ArrayList<Character>  alphabetic =new ArrayList();
static ArrayList<Character> notInAlphabet = new ArrayList<>();
StringBuilder cipher = new StringBuilder();
StringBuilder notInAlph ;
int plain;
String[] splitter;

    public EncDec(String p,String q,String r) {
     pmath = new BigInteger(p); 
     qmath = new BigInteger(q);
     rmath = new BigInteger(r);  
    }

    public EncDec() {
    }

    
    void getchar(){
        String whatuserentered = (String)JOptionPane.showInputDialog(null,"Enter your charachters",
        		"Input",JOptionPane.QUESTION_MESSAGE,null,null," abcdefghijklmnoprstuvwxyz");
        if(whatuserentered==null) {
        	JOptionPane.showMessageDialog(null, "Please Enter your charachters!!");
        }else {
        	for(int i=0;i<whatuserentered.length();i++){
                alphabetic.add(whatuserentered.charAt(i));
             }
        }
    }
   

    
    public void check(){
    	try {
    		if(pmath.gcd(qmath).intValue()==1&&pmath.isProbablePrime(2)&&qmath.isProbablePrime(2)){
    	           nmath = pmath.multiply(qmath);
    	           fimath = pmath.subtract(BigInteger.ONE).multiply(qmath.subtract(BigInteger.ONE));
    	           dmath = rmath.modInverse(fimath);
    	           
    	       } 
    	      if(rmath.equals(dmath)){
    	              dmath = dmath.add(fimath);
    	              dmath = dmath.mod(nmath);
    	           }
		} catch (Exception e) {
			// TODO: handle exception
		}
       
    }
    
 
    void getMessageandEncrypt(String message){ 
    	if(message.length() != 0) {
    		for(int y=0;y<message.length();y++){
         		if(alphabetic.contains(message.charAt(y))) {
            		 plain = alphabetic.indexOf(message.charAt(y));
                     System.out.println(y+".index is  "+plain);
                     plainmath = new BigInteger(String.valueOf(plain));
                     c = plainmath.modPow(rmath, nmath);
                     cipher.append(c).append(" ");
            	}
         }
    	}else { 		 
    		 JOptionPane.showMessageDialog(null, "Please enter your message to Encrypt ");
    	}
    }
          

   void getMessageandDecrypt(String message){
	   try {
		   if(message.length() != 0) {
			   splitter = message.split(" ");
			    for (String splitter1 : splitter) {
			        plainmath = new BigInteger(splitter1);
			        c = plainmath.modPow(dmath, nmath);
			        
			        cipher.append(alphabetic.get(c.intValue()));
			    }
		   }else {
			   JOptionPane.showMessageDialog(null, "Please enter your cipher text.");
		   }
		
	} catch (Exception e) {
//		e.printStackTrace();
		JOptionPane.showMessageDialog(null, "Please change your r value.");
	}
	  
    
    }
    public static void main(String[] args) {
       
    }
    

    
}
