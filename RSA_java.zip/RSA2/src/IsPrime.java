public class IsPrime {
	FindN fn;
	public static void main (String[]args)
	   {
	     int lower = 1, upper = 60, x;
	     for (int i = upper; i >= lower; i--)
	    	 if(isPrime(i)) {
	    		 System.out.println(i);
	    		 
	    		 x = i;
	    		 break;
	    	 }else {
	    		 continue;
	    	 }
	   } 

	   static boolean isPrime (int n)
	   {	     
	     if (n < 2)
	       return false;   
	     for (int i = 2; i < n; i++)
	       {
	     if (n % i == 0)
	        return false;
	       }    
	     return true;
	   }
}
