import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import java.awt.Font;
import java.awt.Color;

public class rsa extends JFrame {

	EncDec ec;
	FindN fn;
    private JFrame frame;
    public JTextField p;
    public JTextField q;
    public JTextField r;
    private JTextField m1;
    private JTextField m2;
    private JTextField ciphertextA;
    private JLabel plaintextA;
    private JButton decryption;
    private JButton encryption;
    private JButton jButton1;
    private JButton jButton2;
    private JButton btnNewButton;

    
    public static void main(String args[]) {
        
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(rsa.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(rsa.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(rsa.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedLookAndFeelException ex) {
            Logger.getLogger(rsa.class.getName()).log(Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            	try {
            		rsa window = new rsa();
                	window.frame.setVisible(true);
                	window.frame.setLocation(EXIT_ON_CLOSE, ABORT);
            	}catch(Exception e){
            		e.printStackTrace();
            	}
            }
        });
    }
   
    public rsa() {
        initialize();
    }

  
    @SuppressWarnings("unchecked")

    private void initialize() {

    	frame = new JFrame();
    	frame.setBackground(new Color(64, 128, 128));
    	frame.getContentPane().setBackground(new Color(137, 197, 197));
    	frame.setTitle("RSA");
		frame.setBounds(700, 650, 768, 390);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        	
        JLabel jLabel1 = new JLabel("RSA");
        frame.getContentPane().add(jLabel1);
        
        JLabel jLabel3 = new JLabel("p = ");
        frame.getContentPane().add(jLabel3);
        jLabel3.setBounds(10, 64, 63, 22);

        JLabel jLabel4 = new JLabel("q = ");
        frame.getContentPane().add(jLabel4);
        jLabel4.setBounds(10, 112, 66, 22);
        
        JLabel jLabel2 = new JLabel("r = ");
        frame.getContentPane().add(jLabel2);
        jLabel2.setBounds(10, 215, 63, 22);
        
        p = new JTextField();
        frame.getContentPane().add(p);
        p.setBounds(45, 57, 218, 37);
        q = new JTextField();
        frame.getContentPane().add(q);
        q.setBounds(45, 105, 218, 37);
        r = new JTextField();
        frame.getContentPane().add(r);
        r.setBounds(45, 208, 218, 37);
        
//        ciphertextA = new
        ciphertextA = new JTextField(); 
        frame.getContentPane().add(ciphertextA);
        ciphertextA.setBounds(428, 87, 300, 34);
       
        JLabel ciphertext = new JLabel("Cipher Text: ");
        frame.getContentPane().add(ciphertext);
        ciphertext.setBounds(351, 98, 80, 22);

        jButton2 = new JButton();
        jButton2.setText("Generate Keys");
        jButton2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
            	generateKeyActionPerformed(evt);
            }
        });
        frame.getContentPane().add(jButton2);
        jButton2.setBounds(70, 267, 121, 41);
          
        m1 = new JTextField();
        frame.getContentPane().add(m1);
        m1.setBounds(428, 42, 209, 34);
      
        encryption = new JButton();
        encryption.setText("Encryption");
        encryption.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                encryptionActionPerformed(evt);
            }
        });
        frame.getContentPane().add(encryption);
        encryption.setBounds(647, 42, 91, 34);

        JLabel jLabel5 = new JLabel("Message: ");
        frame.getContentPane().add(jLabel5);
        jLabel5.setBounds(351, 48, 67, 22);

        plaintextA = new JLabel();
        frame.getContentPane().add(plaintextA);
        plaintextA.setBounds(428, 267, 207, 17);

        decryption = new JButton();
        decryption.setText("Decryption");
        decryption.setAutoscrolls(true);
        decryption.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                decryptionActionPerformed(evt);
            }
        });
        frame.getContentPane().add(decryption);
        decryption.setBounds(647, 209, 91, 34);

        JLabel plaintext = new JLabel("Plain Text: ");
        frame.getContentPane().add(plaintext);
        plaintext.setBounds(351, 267, 68, 17);

        m2 = new JTextField();
        frame.getContentPane().add(m2);
        m2.setBounds(428, 209, 209, 34);

        JLabel jLabel6 = new JLabel("Message: ");
        frame.getContentPane().add(jLabel6);
        jLabel6.setBounds(351, 215, 67, 22);

        JLabel jLabel7 = new JLabel("Reciever");
        jLabel7.setForeground(new Color(255, 0, 0));
        jLabel7.setFont(new Font("Arial Black", Font.BOLD, 14));
        frame.getContentPane().add(jLabel7);
        jLabel7.setBounds(463, 165, 91, 29);

        JLabel jLabel8 = new JLabel("Sender");
        jLabel8.setForeground(new Color(64, 0, 0));
        jLabel8.setFont(new Font("Arial Black", Font.BOLD, 14));
        frame.getContentPane().add(jLabel8);
        jLabel8.setBounds(463, 11, 74, 29);

        jButton1 = new JButton();
        jButton1.setText("send to reciver");
        jButton1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        frame.getContentPane().add(jButton1);
        jButton1.setBounds(488, 129, 110, 30);
        
        btnNewButton = new JButton("Find n");
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent evt) {
        		findnActionPerformed(evt);
        	}
        });
        btnNewButton.setBounds(82, 170, 89, 23);
        frame.getContentPane().add(btnNewButton);

        pack();
    }

    private void findnActionPerformed(ActionEvent evt) {
    	fn = new FindN(p.getText(), q.getText());
    		fn.check();
    	
    }
    
    private void generateKeyActionPerformed(ActionEvent evt) {
    	
    	try {
    		ec = new EncDec(p.getText(), q.getText(), r.getText());

    		String text = r.getText();
        	int rnumber = Integer.parseInt(text);
    		if (!ec.rmath.isProbablePrime(2) ) {
        		JOptionPane.showMessageDialog(null, "Value which you entered is not prime number");
        	}else {
                ec.check();
        		if(rnumber > 2 && rnumber < ec.fimath.intValue()){
            		
                    ec.getchar();
            	}
            	else {
            		JOptionPane.showMessageDialog(null, "Your r is out of range. Go to \"Find n\" button.");
            	}
        	}
		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(null, "Please enter just numerical characters!!");
		} catch (NullPointerException e) {
			
		}
    	
    	
    	
    }

    private void encryptionActionPerformed(ActionEvent evt) {
    	
    	ec = new EncDec(p.getText(), q.getText(), r.getText());
    	try {
    		
    	    ec.check();
    	    ec.getMessageandEncrypt(m1.getText());
    	    ciphertextA.setText(ec.cipher.toString());
		} catch (Exception e) {
			
		}
       
    	
    }

    private void decryptionActionPerformed(ActionEvent evt) {
    	ec = new EncDec(p.getText(), q.getText(), r.getText());
    	try {
    		
    		ec.check();
            ec.getMessageandDecrypt(m2.getText());
            plaintextA.setText(ec.cipher.toString());
            
		} catch (NumberFormatException e) {
			
		}
    	

    }

    private void jButton1ActionPerformed(ActionEvent evt) {
        m2.setText(ciphertextA.getText());
    }
   
    
    

}
