import java.math.BigInteger;

import javax.swing.JOptionPane;

public class FindN {
BigInteger pmath,qmath,nmath,fimath;
IsPrime ip;

    public FindN(String p,String q) {
    	try {
			
    		
        		pmath = new BigInteger(p); 
       	        qmath = new BigInteger(q);
        
    		
		} catch (Exception e) {
			
		}
    	

    }
    public FindN() {
    }
    
    public void check(){
 		
    	try {
    		
    		if(pmath.gcd(qmath).intValue()==1&&pmath.isProbablePrime(2)&&qmath.isProbablePrime(2)){
 	           nmath = pmath.multiply(qmath);
 	           fimath = pmath.subtract(BigInteger.ONE).multiply(qmath.subtract(BigInteger.ONE));
 	           System.out.println("n = "+nmath+"\nfi(n) = "+fimath);  
 	           JOptionPane.showMessageDialog(null, "Your prime r value must be between 1 and "+fimath);
 	       }else if (!pmath.isProbablePrime(2)&&qmath.isProbablePrime(2)) {
 	    	   JOptionPane.showMessageDialog(null,"p is not prime number. Check your p value");
 		}else if(!qmath.isProbablePrime(2)&&pmath.isProbablePrime(2)) {
 			JOptionPane.showMessageDialog(null,"q is not prime number. Check your q value");
 		}else {
 			JOptionPane.showMessageDialog(null,"p and q are not prime number. Check your p and q values");
 		}
    		
			
		} catch (NullPointerException e) {
		}
    		 
    
      
    }
    public static void main(String[] args) {
       
    }
    
}
